# Práctica 4: Juego de Reflejos 🎮⚡

## Objetivo

Crear un **juego que mida tu tiempo de reacción** usando botón y LEDs. El Pico genera una señal visual aleatoria, presionas el botón rápido, y te dice cuántos milisegundos tardaste.

---

## Componentes

| Componente | Cantidad | Pin GPIO |
|-----------|----------|----------|
| LED Rojo (SIGNAL) | 1 | GP15 |
| LED Amarillo (WAIT) | 1 | GP14 |
| Botón | 1 | GP16 |
| Resistencias 330Ω | 2 | - |

**Lenguaje**: C (Pico SDK)  
**Simulador**: Wokwi

---

## Cómo Funciona (3 Estados)

**1. STATE_DONE** - Fin de ronda
   - LEDs: Apagados
   - Esperando para empezar

**2. STATE_WAITING** - Espera (1-5 segundos aleatorio)
   - LED Amarillo: 🟡 Encendido (NO PRESIONES AÚN)
   - Si presionas → **SALIDA FALSA ❌**

**3. STATE_READY** - ¡PRESIONA AHORA!
   - LED Rojo: 🔴 Encendido
   - El cronómetro comienza
   - Presiona el botón lo más rápido posible
   - Se calcula tu tiempo de reacción ⏱️

---

## Partes Principales del Código

### 1. **Configuración de Pines**
```c
#define LED_SIGNAL 15    // LED rojo (cuando presionar)
#define LED_WAIT   14    // LED amarillo (espera)
#define BUTTON     16    // Botón de entrada
```

### 2. **Estados del Juego**
```c
#define STATE_WAITING 0  // Esperando (no presionar aún)
#define STATE_READY   1  // ¡Presiona ahora!
#define STATE_DONE    2  // Ronda completada
```

### 3. **Variables Importantes**
```c
volatile uint8_t state = STATE_DONE;           // Estado actual
volatile uint32_t start_ms = 0;                // Cuándo se encendió el LED rojo
volatile uint32_t reaction_ms = 0;             // Tu tiempo en ms
volatile bool result_ready = false;            // ¿Hay resultado?
volatile bool false_start = false;             // ¿Presionaste antes de tiempo?
```

### 4. **Función: `now_ms()`**
Devuelve el tiempo actual en milisegundos.

### 5. **Función: `show_signal()`**
- Se ejecuta después del delay aleatorio
- Enciende LED rojo
- Apaga LED amarillo
- Inicia el cronómetro

### 6. **Función: `schedule_round()`**
- Inicia una nueva ronda
- Enciende LED amarillo
- Espera 1-5 segundos aleatorio
- Luego ejecuta `show_signal()`

### 7. **Función: `gpio_callback()` - El detector del botón**
```
Si presionas durante STATE_READY:
  ✅ Calcula: tiempo_reaccion = ahora - cuando_se_encendió
  ✅ Guarda el tiempo
  
Si presionas durante STATE_WAITING:
  ❌ SALIDA FALSA (presionaste antes)
  ❌ Cancela el delay y termina ronda
```

### 8. **Bucle Principal**
- Espera a que haya resultado listo
- Si es correcto: muestra tu tiempo en ms
- Si es salida falsa: muestra aviso
- Espera 1.8 segundos
- Espera a que sueltes el botón
- Inicia nueva ronda

---

## Conceptos Clave

**Interrupciones**: El botón avisa al Pico cuando lo presionas (no hay que preguntar constantemente)

**Alarmas**: El Pico espera cierto tiempo sin bloquearse, luego ejecuta la función `show_signal()`

**Debouncing**: Los botones rebotan (múltiples contactos), así que ignora presiones en 80ms

**Delay Aleatorio**: Cada ronda espera 1-5 segundos diferentes para que no anticipes la señal

---

## Flujo del Juego

```
1. Comienza con LEDs apagados
2. Se enciende LED amarillo 🟡
3. Espera 1-5 segundos aleatorio
4. Se enciende LED rojo 🔴 (¡PRESIONA!)
5. Mide el tiempo desde que se encendió hasta que presionaste
6. Muestra tu tiempo de reacción
7. Pausa 1.8 segundos
8. Vuelve al paso 1
```

---

## Cómo Jugar

1. Espera el LED amarillo
2. **NO presiones** mientras esté amarillo (salida falsa)
3. **Presiona rápido** cuando se encienda el LED rojo
4. Ve tu tiempo de reacción en la consola
5. Suelta el botón
6. Se repite automáticamente

---

## Conexiones (Wokwi)

```
Raspberry Pi Pico
├─ GP15 → LED Rojo + Resistencia 330Ω
├─ GP14 → LED Amarillo + Resistencia 330Ω
├─ GP16 → Botón Pulsador
└─ GND → Tierra (para todos)
```

---

## Diferencias con Práctica 2

| Aspecto | Práctica 2 | Práctica 4 |
|--------|-----------|-----------|
| **Lenguaje** | Python | C |
| **Tiempo** | Bloqueante | No-bloqueante |
| **Botón** | Polling | Interrupciones |
| **Velocidad** | Lenta | Rápida |
| **Precisión** | Baja | Alta |

---

## Mejoras Posibles

- Promedio de tiempos (puntuación)
- Delays más cortos en rondas posteriores (dificultad)
- Dos jugadores (dos botones, dos LEDs)
- Pantalla LCD
- Sonidos

---

**🎯 Reto**: ¿Menos de 200ms de tiempo de reacción? ⚡

