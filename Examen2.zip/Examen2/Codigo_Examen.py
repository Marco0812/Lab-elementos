from machine import Pin, PWM, ADC
import _thread
import time

# ==========================================
# CONFIGURACION DE PINES
# ==========================================
led = Pin(13, Pin.OUT)
pwm_led = PWM(Pin(15))
pwm_led.freq(1000)

boton = Pin(16, Pin.IN, Pin.PULL_UP)
adc = ADC(26)

# ==========================================
# ESTADO COMPARTIDO ENTRE LOS DOS NUCLEOS
# ==========================================
led_state = 0
pwm_percent = 0
adc_percent = 0
adc_raw = 0
btn_state = 0
sample_count = 0

# ==========================================
# FUNCIONES AUXILIARES
# ==========================================
def aplicar_pwm(valor):
    global pwm_percent
    pwm_led.duty_u16(int(valor * 65535 / 100))
    pwm_percent = valor


def leer_estado():
    # En MicroPython, estas lecturas y escrituras
    # individuales de enteros son simples.
    return (
        led_state,
        pwm_percent,
        adc_percent,
        btn_state,
        sample_count
    )


def mostrar_status():
    led_v, pwm_v, adc_v, btn_v, samples_v = leer_estado()
    print(
        "STATUS,LED={},PWM={},ADC={},BTN={},SAMPLES={}".format(
            led_v, pwm_v, adc_v, btn_v, samples_v
        )
    )


# ==========================================
# CORE 1: ADQUISICION CONTINUA
# ==========================================
def tarea_adquisicion():
    global adc_percent, adc_raw, btn_state, sample_count

    boton_anterior = 0

    while True:
        # Lectura real del ADC
        lectura = adc.read_u16()
        porcentaje = int(lectura * 100 / 65535)

        adc_raw = lectura
        adc_percent = porcentaje

        # Lectura del boton con PULL_UP:
        # 0 electrico = presionado
        presionado = 1 if boton.value() == 0 else 0
        btn_state = presionado

        # Evento al detectar una nueva pulsacion
        if presionado == 1 and boton_anterior == 0:
            print("EVENT,BUTTON_PRESS")

        boton_anterior = presionado

        # Contador de muestras
        sample_count += 1

        # Periodo de muestreo aproximado: 50 ms
        time.sleep_ms(50)


# ==========================================
# CORE 0: COMANDOS SERIALES
# ==========================================
def procesar_comando(linea):
    global led_state

    linea = linea.strip()

    if linea == "":
        return

    partes = linea.split(",")

    # PING
    if linea == "PING":
        print("PONG")
        return

    # STATUS
    if linea == "STATUS":
        mostrar_status()
        return

    # LED,0 / LED,1
    if partes[0] == "LED":
        if len(partes) != 2:
            print("ERR,BAD_FORMAT")
            return

        if partes[1] not in ("0", "1"):
            print("ERR,BAD_VALUE")
            return

        valor = int(partes[1])
        led.value(valor)
        led_state = valor
        print("ACK,LED,{}".format(valor))
        return

    # PWM,n
    if partes[0] == "PWM":
        if len(partes) != 2:
            print("ERR,BAD_FORMAT")
            return

        try:
            valor = int(partes[1])
        except ValueError:
            print("ERR,BAD_VALUE")
            return

        if valor < 0 or valor > 100:
            print("ERR,PWM_RANGE")
            return

        aplicar_pwm(valor)
        print("ACK,PWM,{}".format(valor))
        return

    # ALL,0 / ALL,1
    if partes[0] == "ALL":
        if len(partes) != 2:
            print("ERR,BAD_FORMAT")
            return

        if partes[1] not in ("0", "1"):
            print("ERR,BAD_VALUE")
            return

        valor = int(partes[1])

        led.value(valor)
        led_state = valor
        aplicar_pwm(valor * 100)

        print("ACK,ALL,{}".format(valor))
        return

    # Comando no reconocido
    print("ERR,UNKNOWN_COMMAND")


# ==========================================
# INICIO DEL SISTEMA
# ==========================================
led.value(0)
aplicar_pwm(0)

print("Sistema iniciado")
print("Comandos: PING, LED, PWM, STATUS, ALL")

# Iniciar el segundo nucleo
_thread.start_new_thread(tarea_adquisicion, ())

# Core 0 permanece atendiendo comandos
while True:
    try:
        comando = input()
        procesar_comando(comando)
    except KeyboardInterrupt:
        # Ctrl+C detiene el programa durante desarrollo.
        raise
    except Exception as error:
        print("ERR,INTERNAL")