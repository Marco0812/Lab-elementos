from machine import Pin, Timer
import time
 
boton_a = Pin(16, Pin.IN, Pin.PULL_UP)
boton_b = Pin(17, Pin.IN, Pin.PULL_UP)
 
led_rojo = Pin(13, Pin.OUT)
led_amarillo = Pin(14, Pin.OUT)
led_verde = Pin(15, Pin.OUT)
 
BLOQUEADO = 0     
ESPERANDO_B = 1      
ACCESO_CONCEDIDO = 2 
BLOQUEO_SEGURIDAD = 3
 
estado = BLOQUEADO
contador_fallos = 0
contador_a_en_acceso = 0
contador_a_en_espera = 0
 
DEBOUNCE_MS = 250
ultimo_a_ms = 0
ultimo_b_ms = 0
 
timer_ventana = Timer(-1)     
timer_acceso = Timer(-1)     
timer_bloqueo_seg = Timer(-1) 
 
 
def set_leds(rojo, amarillo, verde):
    led_rojo.value(rojo)
    led_amarillo.value(amarillo)
    led_verde.value(verde)
 
def ir_bloqueado():
    global estado
    timer_ventana.deinit()
    timer_acceso.deinit()
    estado = BLOQUEADO
    set_leds(1, 0, 0)
    print("[BLOQUEADO] Sistema listo. Presiona A para iniciar.")
 
 
def ir_esperando_b():
    global estado, contador_a_en_espera
    estado = ESPERANDO_B
    contador_a_en_espera = 0
    set_leds(0, 1, 0)
    print("[ESPERANDO B] Boton A detectado. Tienes 5s para presionar B.")
    timer_ventana.init(mode=Timer.ONE_SHOT, period=5000, callback=al_timeout)
 
 
def ir_acceso_concedido():
    global estado, contador_fallos, contador_a_en_acceso
    timer_ventana.deinit()
    estado = ACCESO_CONCEDIDO
    contador_fallos = 0
    contador_a_en_acceso = 0
    set_leds(0, 0, 1)
    print("[ACCESO CONCEDIDO] Correcto. Abriendo por 3s...")
    timer_acceso.init(mode=Timer.ONE_SHOT, period=3000, callback=al_fin_acceso)
 
 
def ir_bloqueo_seguridad():
    global estado
    estado = BLOQUEO_SEGURIDAD
    set_leds(1, 0, 0)
    print("[BLOQUEO DE SEGURIDAD] 3 fallos alcanzados. Bloqueado 10s.")
    timer_bloqueo_seg.init(mode=Timer.ONE_SHOT, period=10000, callback=al_fin_bloqueo_seg)
 
 
def registrar_fallo():
    global contador_fallos
    contador_fallos += 1
    print("[FALLO] Intento fallido. Contador:", contador_fallos)
    if contador_fallos >= 3:
        ir_bloqueo_seguridad()
    else:
        ir_bloqueado()
 

def al_timeout(t):
    if estado == ESPERANDO_B:
        print("[TIMEOUT] No se presiono B a tiempo.")
        registrar_fallo()
 
 
def al_fin_acceso(t):
    if estado == ACCESO_CONCEDIDO:
        ir_bloqueado()
 
 
def al_fin_bloqueo_seg(t):
    global contador_fallos
    contador_fallos = 0
    ir_bloqueado()
 
def interrupcion_a(pin):
    global ultimo_a_ms, contador_a_en_acceso, contador_a_en_espera
    ahora = time.ticks_ms()
    if time.ticks_diff(ahora, ultimo_a_ms) < DEBOUNCE_MS:
        return
    ultimo_a_ms = ahora
 
    if estado == BLOQUEADO:
        ir_esperando_b()
    elif estado == ESPERANDO_B:
        contador_a_en_espera += 1
        print("[A] Presionado durante espera de B.")
        if contador_a_en_espera >= 3:
            timer_ventana.deinit()
            ir_bloqueo_seguridad()
    elif estado == ACCESO_CONCEDIDO:
        contador_a_en_acceso += 1
        print("[A] Presionado durante acceso concedido.")
        if contador_a_en_acceso >= 3:
            timer_acceso.deinit()
            ir_bloqueo_seguridad()
    else:
        print("[A] Boton A presionado de nuevo, se ignora (ya esta en proceso).")
 
 
def interrupcion_b(pin):
    global ultimo_b_ms
    ahora = time.ticks_ms()
    if time.ticks_diff(ahora, ultimo_b_ms) < DEBOUNCE_MS:
        return
    ultimo_b_ms = ahora
 
    if estado == BLOQUEADO:
        registrar_fallo()
    elif estado == ESPERANDO_B:
        ir_acceso_concedido()
    else:
        print("[B] Boton B presionado, se ignora (fuera de ventana valida).")
 
 
boton_a.irq(trigger=Pin.IRQ_FALLING, handler=interrupcion_a)
boton_b.irq(trigger=Pin.IRQ_FALLING, handler=interrupcion_b)
 
ir_bloqueado()
 
while True:
    time.sleep(1)