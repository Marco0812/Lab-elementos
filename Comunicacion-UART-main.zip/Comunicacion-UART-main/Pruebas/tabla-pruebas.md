# Tabla de pruebas — Comunicación UART

**Proyecto:** Comunicación UART con Raspberry Pi Pico  
**Entorno:** MicroPython y Thonny  
**Conexión:** UART0, GP0 (TX) conectado a GP1 (RX)

## Resultados de las pruebas

| ID | Prueba | Resultado esperado | Estado | Observaciones |
|---|---|---|---|---|
| T01 | Inicio del programa | El programa inicia sin errores | PASS | El programa inició correctamente. |
| T02 | Envío de comando desde USB/REPL | El comando se envía desde la consola | PASS | El envío del comando funcionó correctamente. |
| T03 | Recepción mediante UART | Se reciben los datos transmitidos | PASS | La recepción UART funcionó correctamente. |
| T04 | Comando PING | Se obtiene la respuesta correspondiente | PASS | El comando PING funcionó correctamente. |
| T05 | Comando SET | Se actualiza el parámetro solicitado | PASS | Se recuerda haber probado este comando. |
| T06 | Comando GET | Se devuelve el valor configurado | PASS | Se recuerda haber probado este comando. |
| T07 | Comando ALL | Se devuelve el estado completo | PASS | Se recuerda haber probado este comando. |
| T08 | Comando inválido | Se gestiona un comando no reconocido | PASS | El programa contempla el comando inválido. |
| T09 | Entrada vacía o mal formada | Se gestiona sin bloquear el programa |Pass | |
| T10 | Solicitudes consecutivas | Se procesan varias solicitudes correctamente | Pendiente | |

## Criterios de evaluación

- **PASS:** prueba confirmada como satisfactoria.
- **FAIL:** prueba ejecutada que no cumplió el resultado esperado.
- **Pendiente:** prueba sin resultado confirmado.

## Conclusión

Durante la práctica se comprobó el inicio del programa, el envío de comandos desde la consola USB/REPL y la comunicación UART. También se reportó el funcionamiento de los comandos PING, SET, GET y ALL, así como el manejo de comandos inválidos.

Las pruebas de entradas vacías o mal formadas y de solicitudes consecutivas quedan pendientes de confirmación.