# Práctica: Comunicación UART con Raspberry Pi Pico
Juan Pablo Ruiz Gil
Marco Uriel Castaneda Avila
## 1. Objetivo

Implementar y comprobar una comunicación UART mediante MicroPython, utilizando Thonny como terminal USB para enviar comandos y recibir respuestas de la Raspberry Pi Pico.

Se emplea una conexión física de loopback entre GP0 (TX) y GP1 (RX) para comprobar la transmisión y recepción de datos.

## 2. Materiales

- Raspberry Pi Pico / Pico W / Pico 2 (especificar el modelo utilizado).
- Cable USB de datos.
- Protoboard, si se utiliza.
- Jumper macho-macho para conectar GP0 con GP1.
- Thonny IDE.

## 3. Conexiones

| Señal | GPIO de la Pico | Función |
|---|---|---|
| UART0 TX | GP0 | Transmisión |
| UART0 RX | GP1 | Recepción |
| GND | GND | Referencia eléctrica común |

**Loopback:** conectar físicamente GP0 con GP1.

La conexión permite que los datos enviados por TX regresen a RX para verificar la comunicación.

## 4. Funcionamiento

1. Conectar la Pico a la computadora mediante USB.
2. Abrir Thonny y seleccionar el intérprete MicroPython correspondiente.
3. Ejecutar `src/main.py`.
4. Enviar los comandos desde la consola de Thonny.
5. Verificar las respuestas recibidas y registrar los resultados en la tabla de pruebas.

## 5. Conceptos teóricos

- **USB/REPL:** el USB permite conectar la Pico con Thonny y acceder a la consola interactiva de MicroPython. No es lo mismo que la interfaz UART0.
- **TX/RX:** TX transmite datos y RX los recibe. En loopback se conecta TX con RX.
- **Baud rate:** velocidad de señalización configurada en bits por segundo; ambos extremos deben utilizar una configuración compatible.
- **8N1:** 8 bits de datos, sin paridad (N) y 1 bit de parada.
- **Trama:** unidad de datos transmitida, normalmente delimitada en esta práctica mediante un salto de línea.
- **ACK/ERR:** respuesta que indica que un comando fue aceptado o que ocurrió un error.

## 6. Evidencias

- Captura de Thonny mostrando `USB CMD`, `UART RX` y la respuesta.
- Fotografía de la Raspberry Pi Pico con el jumper GP0 → GP1.
- Código final ejecutable.

## 7. Resultados

Consultar `pruebas/tabla-pruebas.md` para revisar los casos ejecutados y sus resultados PASS/FAIL.

## 8. Conclusión

La práctica permite comprobar la transmisión y recepción UART mediante loopback, diferenciar la consola USB/REPL de UART0 y validar el procesamiento de comandos mediante respuestas ACK/ERR.

## 9. Simulación opcional

Wokwi se considera únicamente un respaldo visual. La validación principal se realiza con la Raspberry Pi Pico física y Thonny.